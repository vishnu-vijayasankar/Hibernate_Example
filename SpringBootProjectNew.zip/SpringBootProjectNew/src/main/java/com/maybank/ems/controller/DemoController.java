package com.maybank.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

	@Value("${welcome.message}")
	private String message;
	
	@RequestMapping("/display")
	public String getMessage() {
		return message;
	}
	
	@Autowired
	UserConfiguration userconfiguration;
	@RequestMapping("/displayUser")
	public String getUser() {
		System.out.println(userconfiguration);
		return null;
	}
	
	
}

package com.maybank.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.maybank.ems.model.Employee;
import com.maybank.ems.service.EmployeeService;

@Controller

public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("passengerForm/savePassenger")
	public String addPassenger(Employee passenger) {
		employeeService.savePassenger(passenger);
		return "success";
	}
	
	@RequestMapping("/passengerForm")
	public ModelAndView passengerForm() {
		ModelAndView view = new ModelAndView();
		view.setViewName("passengerForm");
		view.addObject("pssngr", new Employee());
		return view;
	}
}

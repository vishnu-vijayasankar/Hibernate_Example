package com.maybank.ems.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.maybank.ems.model.Employee;
import com.maybank.ems.service.EmployeeService;


@RestController
@RequestMapping("/passenger")

public class EmployeeRestController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value = "{pnr}", method = RequestMethod.GET)
	public Optional<Employee> getAllPassengerById(@PathVariable("pnr")Integer p) {
		return employeeService.getAllPassengerById(p);
	}
	
	@RequestMapping("/getAllPassenger")
	public java.util.List<Employee> getAllPassenger() {
		return employeeService.getAllPassenger();
	}
	
	@RequestMapping(value = "{pnr}", method = RequestMethod.DELETE)
	public void deletePassenger(@PathVariable("pnr")Integer p) {
		employeeService.deletePassenger(p);
	}

}

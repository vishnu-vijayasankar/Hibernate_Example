package com.maybank.ems.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.maybank.ems.model.Employee;

@Repository
public interface EmployeeDAO extends CrudRepository<Employee, Integer> {

}

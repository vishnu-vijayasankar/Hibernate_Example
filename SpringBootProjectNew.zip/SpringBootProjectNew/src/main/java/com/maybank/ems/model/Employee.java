package com.maybank.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Passenger")

public class Employee {
	
	@Id
	private int pnrNumber;
	
	@Column
	private String firstName;
	
	@Column
	private int totalFare;

	public Employee() {
	}
	
	public Employee(int pnrNumber, String firstName, int totalFare) {
		super();
		this.pnrNumber = pnrNumber;
		this.firstName = firstName;
		this.totalFare = totalFare;
	}

	public int getPnrNumber() {
		return pnrNumber;
	}

	public void setPnrNumber(int pnrNumber) {
		this.pnrNumber = pnrNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}

	@Override
	public String toString() {
		return "Employee [pnrNumber=" + pnrNumber + ", firstName=" + firstName + ", totalFare=" + totalFare + "]";
	}
	
}

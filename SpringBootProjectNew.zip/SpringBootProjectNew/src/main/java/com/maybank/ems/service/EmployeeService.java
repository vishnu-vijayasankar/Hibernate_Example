package com.maybank.ems.service;

import java.util.List;
import java.util.Optional;

import com.maybank.ems.model.Employee;



public interface EmployeeService {
	public void savePassenger(Employee passenger);
	public List<Employee> getAllPassenger();
	public void deletePassenger(int pnr);
	public Optional<Employee> getAllPassengerById(int pnr);
}

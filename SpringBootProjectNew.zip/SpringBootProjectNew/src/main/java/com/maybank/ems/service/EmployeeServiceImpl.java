package com.maybank.ems.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maybank.ems.dao.EmployeeDAO;
import com.maybank.ems.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDAO employeeDAO;

	@Override
	public void savePassenger(Employee passenger) {
		// TODO Auto-generated method stub
		employeeDAO.save(passenger);
	}

	@Override
	public java.util.List<Employee> getAllPassenger() {
		// TODO Auto-generated method stub
		return (java.util.List<Employee>) employeeDAO.findAll();
	}

	@Override
	public void deletePassenger(int pnr) {
		// TODO Auto-generated method stub
		employeeDAO.deleteById(pnr);
	}

	@Override
	public Optional<Employee> getAllPassengerById(int pnr) {
		// TODO Auto-generated method stub
		return employeeDAO.findById(pnr);
	}

}

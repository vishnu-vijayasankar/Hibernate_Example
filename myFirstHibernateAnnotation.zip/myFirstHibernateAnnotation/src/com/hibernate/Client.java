package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Client {
	public static void main(String[] args) {
		Customer customer = new Customer(111, "VVS", "Kerala", 77777);
		
		AnnotationConfiguration configuration = new AnnotationConfiguration().configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		org.hibernate.Transaction transaction = session.beginTransaction();
		session.save(customer);
		
		transaction.commit();
		session.clear();
		
		System.out.println("Saved");
	}
}
